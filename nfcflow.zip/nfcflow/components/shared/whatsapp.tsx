'use client';

import { useMemo } from 'react';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { useStoreSettings } from '@/hooks/use-store-settings';

const ENV_LINK = (process.env.NEXT_PUBLIC_WHATSAPP_LINK || '').trim();

/** Monta o link wa.me. Sem número, devolve '#'. O número vem SEMPRE de ADMIN → Suporte (nada fixo no código). */
export function whatsappUrl(phone: string, message?: string): string {
  // Link completo opcional (NEXT_PUBLIC_WHATSAPP_LINK) usado só quando o ADMIN ainda não configurou o número
  if (phone.startsWith('http')) return phone;
  const clean = (phone || '').replace(/\D/g, '');
  if (!clean) return '#';
  return message ? `https://wa.me/${clean}?text=${encodeURIComponent(message)}` : `https://wa.me/${clean}`;
}

export function WhatsAppIcon({ className = 'h-6 w-6' }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className={className} fill="currentColor">
      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
    </svg>
  );
}

interface Props {
  message?: string;
  phone?: string;   // opcional: sobrescreve o número do ADMIN
  className?: string;
  children?: React.ReactNode;
  reseller?: boolean;
}

/** Botão de suporte via WhatsApp (número configurado em ADMIN → Suporte). */
export function WhatsAppButton({ message, phone, className, children }: Props) {
  const s = useStoreSettings();
  const finalPhone = phone || s.supportWhatsapp || ENV_LINK;
  const url = useMemo(() => whatsappUrl(finalPhone, message || 'Olá! Preciso de ajuda com o NFCFLOW.'), [finalPhone, message]);

  if (!finalPhone) {
    if (!s.loaded) return null;
    return <p className="text-sm text-muted-foreground">Suporte por WhatsApp indisponível no momento.</p>;
  }
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        'inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-[#25D366] px-5 text-base font-semibold text-white shadow-lg shadow-green-500/20 transition-all duration-200 hover:scale-[1.02] hover:bg-[#20bd5a] active:scale-[0.98]',
        className
      )}
    >
      <WhatsAppIcon className="h-5 w-5" />
      {children ?? 'Falar com o suporte no WhatsApp'}
    </a>
  );
}

const FLOAT_ALLOWED_PATHS = ['/', '/login', '/cadastro', '/register'];

/** Botão flutuante animado. Aparece somente na landing page, no login e no cadastro. */
export function WhatsAppFloat({ message, phone }: Props) {
  const s = useStoreSettings();
  const pathname = usePathname() || '';
  const finalPhone = phone || s.supportWhatsapp || ENV_LINK;
  const url = useMemo(() => whatsappUrl(finalPhone, message || 'Olá! Vim pelo site NFCFLOW.'), [finalPhone, message]);

  if (!finalPhone) return null;
  // Só aparece na landing page, no login e no cadastro (nunca dentro dos painéis /admin e /painel)
  if (!FLOAT_ALLOWED_PATHS.includes(pathname.replace(/\/+$/, '') || '/')) return null;

  const inPanel = false;
  return (
    <a
      href={url}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="WhatsApp Suporte"
      className={cn(
        'fixed right-5 z-[60] flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-xl shadow-green-500/30 transition-transform duration-200 hover:scale-110 active:scale-95',
        inPanel ? 'bottom-[calc(5.5rem+env(safe-area-inset-bottom))]' : 'bottom-[calc(1.25rem+env(safe-area-inset-bottom))]'
      )}
    >
      <span className="absolute inset-0 animate-ping rounded-full bg-[#25D366] opacity-30" />
      <WhatsAppIcon className="relative h-7 w-7" />
    </a>
  );
}
